const BASE = 'https://api.bybit.com'; // Si hay bloqueo, usar 'https://api.bytick.com'

export default async function handler(req, res) {
  try {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET');

    const url = new URL(req.url, 'http://x');
    const path = url.pathname.toLowerCase();
    const q = Object.fromEntries(url.searchParams.entries());

    const symbol = (q.symbol || 'BTCUSDT').toUpperCase();
    const category = 'linear';
    const interval = String(q.interval || '240');
    const limit = String(Math.min(Math.max(Number(q.limit || 200), 1), 1000));

    if (path.endsWith('/ticker')) {
      const r = await getJSON(`${BASE}/v5/market/tickers?category=${category}&symbol=${symbol}`);
      const t = r.list?.[0];
      if (!t) throw new Error('empty ticker');
      return res.status(200).json({
        symbol,
        last: +t.lastPrice,
        index: +t.indexPrice,
        mark: +t.markPrice,
        vol24h: +t.volume24h,
        change24hPct: +t.price24hPcnt * 100
      });
    }

    if (path.endsWith('/orderbook')) {
      const depth = String(Math.min(Math.max(Number(limit), 1), 200));
      const r = await getJSON(`${BASE}/v5/market/orderbook?category=${category}&symbol=${symbol}&limit=${depth}`);
      return res.status(200).json({
        symbol,
        bids: (r.b || []).map(([p, s]) => [+p, +s]),
        asks: (r.a || []).map(([p, s]) => [+p, +s])
      });
    }

    if (path.endsWith('/klines')) {
      const r = await getJSON(`${BASE}/v5/market/kline?category=${category}&symbol=${symbol}&interval=${interval}&limit=${limit}`);
      const rows = (r.list || []).slice().sort((a, b) => +a[0] - +b[0]);
      const kl = rows.map(k => [+k[0], +k[1], +k[2], +k[3], +k[4], +k[5]]);
      return res.status(200).json({ symbol, interval: +interval, klines: kl });
    }

    if (path.endsWith('/indicators')) {
      const r = await getJSON(`${BASE}/v5/market/kline?category=${category}&symbol=${symbol}&interval=${interval}&limit=${limit}`);
      const rows = (r.list || []).slice().sort((a, b) => +a[0] - +b[0]);
      const closes = rows.map(k => +k[4]);

      const ema20 = ema(closes, 20);
      const ema50 = ema(closes, 50);
      const ema200 = ema(closes, 200);
      const rsi14 = rsi(closes, 14);
      const { macd, signal, hist } = macdCalc(closes, 12, 26, 9);

      const last = closes.length - 1;
      return res.status(200).json({
        symbol,
        interval: +interval,
        latest: {
          close: closes[last],
          ema20: ema20[last] ?? null,
          ema50: ema50[last] ?? null,
          ema200: ema200[last] ?? null,
          rsi14: rsi14[last] ?? null,
          macd: macd[last] ?? null,
          macdSignal: signal[last] ?? null,
          macdHist: hist[last] ?? null
        }
      });
    }

    return res.status(200).json({
      ok: true,
      endpoints: [
        '/api/ticker?symbol=BTCUSDT',
        '/api/orderbook?symbol=BTCUSDT&limit=50',
        '/api/klines?symbol=BTCUSDT&interval=240&limit=300',
        '/api/indicators?symbol=BTCUSDT&interval=240&limit=300'
      ]
    });

  } catch (err) {
    return res.status(500).json({ error: String(err.message || err) });
  }
}

async function getJSON(url) {
  const r = await fetch(url, { headers: { 'User-Agent': 'bybit-proxy' } });
  if (!r.ok) throw new Error(`HTTP ${r.status} ${await r.text()}`);
  const j = await r.json();
  if (j.retCode !== 0) throw new Error(`Bybit retCode ${j.retCode}: ${j.retMsg}`);
  return j.result;
}

function ema(arr, p) {
  if (!arr.length) return [];
  const k = 2 / (p + 1);
  const out = new Array(arr.length);
  let prev = arr[0];
  out[0] = prev;
  for (let i = 1; i < arr.length; i++) {
    prev = arr[i] * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

function rsi(arr, period = 14) {
  if (arr.length < period + 1) return new Array(arr.length).fill(null);
  const out = new Array(arr.length).fill(null);
  let gains = 0, losses = 0;
  for (let i = 1; i <= period; i++) {
    const ch = arr[i] - arr[i - 1];
    if (ch > 0) gains += ch; else losses -= ch;
  }
  gains /= period; losses /= period;
  out[period] = 100 - 100 / (1 + gains / (losses || 1e-9));
  for (let i = period + 1; i < arr.length; i++) {
    const ch = arr[i] - arr[i - 1];
    gains = (gains * (period - 1) + Math.max(ch, 0)) / period;
    losses = (losses * (period - 1) + Math.max(-ch, 0)) / period;
    out[i] = 100 - 100 / (1 + gains / (losses || 1e-9));
  }
  return out;
}

function macdCalc(arr, fast = 12, slow = 26, signalP = 9) {
  if (!arr.length) return { macd: [], signal: [], hist: [] };
  const emaFast = ema(arr, fast);
  const emaSlow = ema(arr, slow);
  const macd = arr.map((_, i) => (emaFast[i] ?? 0) - (emaSlow[i] ?? 0));
  const signal = ema(macd, signalP);
  const hist = macd.map((v, i) => v - (signal[i] ?? 0));
  return { macd, signal, hist };
}
